use leptos::*;
use bridge::InstructionClient; 
use domain::*; 

#[component]
fn App() -> impl IntoView {
    // 1. Initialize Client and Context
    let client = InstructionClient::new("http://localhost:9000");
    provide_context(client);

    // 2. Reactive Signals
    let (search_query, set_search_query) = create_signal(String::new());
    let (evidence_filter, set_evidence_filter) = create_signal("all".to_string());
    let (response_text, set_response_text) = create_signal("Connected to Http Client...".to_string());

    // --- Helper: Dynamic Search ---
    let perform_search = move || {
        let client = use_context::<InstructionClient>().expect("Client missing");
        let query = search_query.get();
        spawn_local(async move {
            if query.is_empty() { return; }
            set_response_text.set(format!("Searching for '{}'...", query));
            match client.search_instructions(&query).await {
                Ok(r) => set_response_text.set(format!("{:#?}", r)),
                Err(e) => set_response_text.set(format!("Search Error: {}", e)),
            }
        });
    };

    // --- Helper: Filtered Fetch ---
    let run_filtered_fetch = move || {
        let client = use_context::<InstructionClient>().expect("Client missing");
        let filter = evidence_filter.get();
        spawn_local(async move {
            set_response_text.set(format!("Applying filter: evidence={}...", filter));
            let params = match filter.as_str() {
                "true" => vec![("evidence", "true")],
                "false" => vec![("evidence", "false")],
                _ => vec![],
            };
            match client.get_instructions(&params).await {
                Ok(r) => set_response_text.set(format!("{:#?}", r)),
                Err(e) => set_response_text.set(format!("Filter Error: {}", e.to_string())),
            }
        });
    };

    // --- Helper: Test Runner (1-18) ---
    let run_test = move |id: usize| {
        let client = use_context::<InstructionClient>().expect("Client missing");
        spawn_local(async move {
            set_response_text.set(format!("Executing Test Case {}...", id));
            let res: Result<String, String> = match id {
                // FETCH CASES (GET) - map_err used for anyhow compatibility
                1 => client.get_instructions(&[]).await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                2 => client.get_instructions(&[("page", "2")]).await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                3 => client.get_by_id("WI-007").await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                4 => client.get_instructions(&[("evidence", "true")]).await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                5 => client.get_instructions(&[("evidence", "true"), ("page", "2")]).await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                6 => client.get_instructions(&[("tool", "LV-02")]).await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                7 => client.get_instructions(&[("tool", "LV-02"), ("tool", "MT-09")]).await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                8 => client.search_instructions("align").await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),
                9 => client.search_instructions("Verify").await.map(|r| format!("{:#?}", r)).map_err(|e| e.to_string()),

                // POST CASES (COMPLETION)
                10 => client.complete_step(&CompletionRequest { instruction_id: "WI-002".into(), step_sequence: 201, num_val: Some(5.0), bool_val: None, text_val: None, has_media: false })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                11 => client.complete_step(&CompletionRequest { instruction_id: "WI-002".into(), step_sequence: 201, num_val: Some(10.0), bool_val: None, text_val: None, has_media: false })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                12 => client.complete_step(&CompletionRequest { instruction_id: "WI-002".into(), step_sequence: 201, num_val: None, bool_val: None, text_val: None, has_media: false })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                13 => client.complete_step(&CompletionRequest { instruction_id: "WI-001".into(), step_sequence: 101, num_val: None, bool_val: Some(true), text_val: None, has_media: true })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                14 => client.complete_step(&CompletionRequest { instruction_id: "WI-001".into(), step_sequence: 101, num_val: None, bool_val: None, text_val: None, has_media: true })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                15 => client.complete_step(&CompletionRequest { instruction_id: "WI-001".into(), step_sequence: 101, num_val: None, bool_val: Some(true), text_val: None, has_media: false })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                16 => client.complete_step(&CompletionRequest { instruction_id: "WI-007".into(), step_sequence: 702, num_val: None, bool_val: Some(true), text_val: None, has_media: true })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                17 => client.complete_step(&CompletionRequest { instruction_id: "WI-007".into(), step_sequence: 702, num_val: None, bool_val: Some(true), text_val: None, has_media: false })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                18 => client.complete_step(&CompletionRequest { instruction_id: "WI-007".into(), step_sequence: 702, num_val: None, bool_val: None, text_val: None, has_media: true })
				.await
				.map(|r| format!("{:#?}", r))
				.map_err(|e| e.to_string()),
                
                _ => Ok("Invalid ID".into()),
            };

            match res {
                Ok(data) => set_response_text.set(data),
                Err(e) => set_response_text.set(format!("API Error: {}", e)),
            }
        });
    };

    view! {
        <div style="font-family: sans-serif; padding: 20px; max-width: 1200px; margin: auto;">
            <h1 style="color: #2c3e50; text-align: center; border-bottom: 2px solid #3498db; padding-bottom: 10px;">
                "kschabriAI OpenDWI Interface"
            </h1>
            
            // --- ROW 1: CONTROLS ---
            <div style="display: flex; gap: 20px; margin: 20px 0; background: #f8f9fa; padding: 20px; border-radius: 8px; border: 1px solid #dee2e6;">
                <div style="flex: 2; display: flex; gap: 10px;">
                    <input type="text" placeholder="Search instructions..." style="flex: 1; padding: 10px; border-radius: 4px; border: 1px solid #ced4da;"
                        prop:value=search_query
                        on:input=move |ev| set_search_query.set(event_target_value(&ev))
                        on:keydown=move |ev| { if ev.key() == "Enter" { perform_search(); } }
                    />
                    <button on:click=move |_| perform_search() style="padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer;">"Search"</button>
                </div>
                
                <div style="flex: 1; display: flex; gap: 10px;">
                    <select style="flex: 1; padding: 10px; border-radius: 4px; border: 1px solid #ced4da;"
                        on:change=move |ev| set_evidence_filter.set(event_target_value(&ev))
                        prop:value=evidence_filter>
                        <option value="all">"All Evidence"</option>
                        <option value="true">"Required"</option>
                        <option value="false">"Optional"</option>
                    </select>
                    <button on:click=move |_| run_filtered_fetch() style="padding: 10px 20px; background: #2ecc71; color: white; border: none; border-radius: 4px; cursor: pointer;">"Filter"</button>
                </div>
            </div>

            // --- ROW 2: TEST GRIDS ---
            <div style="display: flex; gap: 20px;">
                <div style="flex: 1; background: white; border: 1px solid #ddd; padding: 15px; border-radius: 8px;">
                    <h3 style="color: #2980b9; margin-top:0;">"Fetch Tests (GET)"</h3>
                    <div style="display: grid; grid-template-columns: 1fr; gap: 6px;">
                        <button on:click=move |_| run_test(1)>"1. Fetch All"</button>
                        <button on:click=move |_| run_test(2)>"2. Page 2"</button>
                        <button on:click=move |_| run_test(3)>"3. WI-007 Detail"</button>
                        <button on:click=move |_| run_test(4)>"4. Evidence Required"</button>
                        <button on:click=move |_| run_test(5)>"5. Evidence + Page 2"</button>
                        <button on:click=move |_| run_test(6)>"6. Tool LV-02"</button>
                        <button on:click=move |_| run_test(7)>"7. Tools LV & MT"</button>
                        <button on:click=move |_| run_test(8)>"8. Search 'align'"</button>
                        <button on:click=move |_| run_test(9)>"9. Search 'Verify'"</button>
                    </div>
                </div>

                <div style="flex: 1; background: white; border: 1px solid #ddd; padding: 15px; border-radius: 8px;">
                    <h3 style="color: #c0392b; margin-top:0;">"Completion Tests (POST)"</h3>
                    <div style="display: grid; grid-template-columns: 1fr; gap: 6px;">
                        <button on:click=move |_| run_test(10)>"10. Numeric Pass (5.0)"</button>
                        <button on:click=move |_| run_test(11)>"11. Numeric Fail (10.0)"</button>
                        <button on:click=move |_| run_test(12)>"12. Numeric Missing"</button>
                        <button on:click=move |_| run_test(13)>"13. Boolean Pass (Media=T)"</button>
                        <button on:click=move |_| run_test(14)>"14. Boolean Missing"</button>
                        <button on:click=move |_| run_test(15)>"15. Boolean Fail (Media=F)"</button>
                        <button on:click=move |_| run_test(16)>"16. Evidence Pass (Media=T)"</button>
                        <button on:click=move |_| run_test(17)>"17. Evidence Fail (Media=F)"</button>
                        <button on:click=move |_| run_test(18)>"18. Evidence Missing Val"</button>
                    </div>
                </div>
            </div>

            // --- ROW 3: LOGS ---
            <div style="margin-top: 20px;">
                <h4 style="color: #7f8c8d; margin-bottom: 5px;">"Real-time API Log"</h4>
                <pre style="background: #222; color: #44bd32; padding: 20px; border-radius: 8px; font-size: 14px; min-height: 300px; overflow: auto; white-space: pre-wrap; font-family: monospace;">
                    {move || response_text.get()}
                </pre>
            </div>
        </div>
    }
}

fn main() {
    mount_to_body(|| view! { <App/> })
}
//jairamashivajikijaimaachanchalikantinijikijaimaajaimaajaijaimaamaamaajairamashivajikijaisiyawarramchandamaababajikijaihodashrathkakakakimataojikijaihobholedadewarisuryedadeshwarjikijaimaamaaanjanipapajikijaimaa